<?php
/**
 * Title: Template Full Width
 * Slug: blockskit-base/template-full-width
 * Categories: template
 * Inserter: false
 */
?>

<!-- wp:group {"tagName":"main","style":{"spacing":{"margin":{"top":"0","bottom":"0"}}},"layout":{"type":"constrained"}} -->
<main class="wp-block-group" style="margin-top:0;margin-bottom:0"><!-- wp:post-content {"align":"full","layout":{"type":"default"}} /--></main>
<!-- /wp:group -->