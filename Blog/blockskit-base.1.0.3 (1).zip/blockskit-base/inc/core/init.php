<?php
/**
 * Initiate core files
 */
include 'block-patterns.php';
include 'block-styles.php';